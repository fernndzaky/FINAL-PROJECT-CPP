//
// Created by Fernandha Dzaky Saputra on 2019-06-12.
//

#include <iostream>
#include <string>
#include <iomanip>

#include "admin.h"
#include "time.h"
#include "LinkedList.h"

using namespace std;

// PRINTING THE HEAD OF THE PARKING LOT
void Admin::checkParkingLot() {
    cout << endl << "------------------------------------------------------------" << endl;
    cout << left << setw(15) << "LOT NUM";
    cout << left << setw(20) << "STATUS";
    cout << left << setw(15) << "EST TIME";
    cout << left << setw(15) << "BOOKED BY";

    cout << endl << "------------------------------------------------------------" << endl;

}

// PRINTING USERS THAT ARE IN THE QUEUE LIST

void Admin::showQueue() {
    // IF QUEUE IS EMPTY THEN PRINT THERE IS NO QUEUE
    if(isQueueEmpty()){
        cout << "There is no Queue !" << endl;
    }
    // IF QUEUE IS NOT EMPTY
    else{
        int num = 1;

        while(!userQueue.empty()){
            // PRINT THE TOP OF THE QUEUE
            cout << "Queue List : " << endl;
            cout << num << ". Username : " << userQueue.front();
            // PUSH TO TEMPORARY QUEUE
            tempQueue.push(userQueue.front());
            // POP TO MOVE TO THE NEXT ITEM
            userQueue.pop();
            num++;
        }

        // PUT ALL THE USERS BACK TO THE USER QUEUE FROM THE TEMPORARY QUEUE
        while(!tempQueue.empty()){

            userQueue.push(tempQueue.front());
            tempQueue.pop();
        }
        cout << endl;
    }
}

bool Admin::isQueueEmpty() {
    if(userQueue.empty())
        return true;
    else
        return false;
}
// BOOLEAN FUNCTIONS TO FIND USER IN QUEUE
bool Admin::findUserInQueue(string username) {
    // PUSH ALL DATA FROM USERQUEUE TO TEMPORARY QUEUE
    while(!userQueue.empty()){
        tempQueue.push(userQueue.front());
        currQueue.push(userQueue.front());
        userQueue.pop();
    }
    // PUT BACK ALL THE DATA BACK TO THE USER QUEUE FROM TEMPORARY QUEUE
    while(!currQueue.empty()){
        userQueue.push(currQueue.front());
        currQueue.pop();
    }


    while(!tempQueue.empty()){
        // IF THE USER FOUND IN THE TEMPORARY QUEUE , RETURN TRUE
        if(tempQueue.front() == username){
            while(!currQueue.empty()){
                currQueue.pop();
            }
            while(!tempQueue.empty()){
                tempQueue.pop();
            }
            return true;
        }
        currQueue.push(tempQueue.front());
        tempQueue.pop();
    }
    // IF THE USER IS NOT FOUND IN THE TEMPORARY QUEUE , RETURN FALSE
    if(tempQueue.empty()){
        while(!currQueue.empty()){
            currQueue.pop();
        }
        return false;
    }

}




