//
// Created by Fernandha Dzaky Saputra on 2019-06-24.
//
#include <iostream>
#include <string>
using namespace std;
#ifndef FINALPROJECT_TREES_H
#define FINALPROJECT_TREES_H

class Trees{
private:
    int totalUser;
public:
    // STRUCT FOR EVERY NODE IN THE TREE
    struct Node{
        string name;
        int id;
        Node * left;
        Node * right;
    };
    Node * root;
    // CONSTRUCTOR FOR ROOT POINTING TO NULL
    Trees(){
        root = NULL;
    }

    Node * getNewNode(string name , int id);
    Node * insert(Node* root ,string name ,int id);
    bool Search(Node * root , int id);
    string getFullName(Node * root , int id);
    void showUser(Node * root);

};


#endif //FINALPROJECT_TREES_H
