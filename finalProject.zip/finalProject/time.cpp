//
// Created by Fernandha Dzaky Saputra on 2019-06-12.
//
#include <cstdlib>
#include <iostream>
#include <time.h>
#include <sstream>
#include "time.h"


// SNIPPED CODE FROM INTERNET TO TAKE CURRENT TIME

using namespace std;

// ADDING TIME
void Time::addTime(Time t1, Time t2) {
    ss = t1.ss * t2.ss;
    mm = ss/60;
    ss = ss%60;
    mm += t1.mm + t2.mm;
    hh = mm/60;
    mm = mm%60;
    hh += t1.hh + t2.hh;

}
// READING CURRENT TIME
void Time:: readtime(int h , int m , int s){
    hh = h;
    mm = m;
    ss = s;
}

// PRINTING CURRENT TIME
string Time::showtime(){
     return to_string(hh)  + ":" + to_string(mm);
}


// RETURN THE CURRENT MINUTE OF THE TIME
int Time::returnMinute(string s) {
    string delimiter = ":";

    size_t pos = 0;
    std::string token;
    while ((pos = s.find(delimiter)) != std::string::npos) {
        token = s.substr(0, pos);
        //std::cout << token << std::endl;
        s.erase(0, pos + delimiter.length());
    }
    int x = stoi(s);
    return x;
}