//
// Created by Fernandha Dzaky Saputra on 2019-06-12.
//
#include <iostream>
#include <string>
using namespace std;
#ifndef FINALPROJECT_CUSTOMER_H
#define FINALPROJECT_CUSTOMER_H

class Customer{
public:
    // EMPTY STRING FOR ACTIVE USER
    string username = "";
    // EMPTY INT FOR ID VERIFICATION
    int id;
    void printLogin();
};

#endif //FINALPROJECT_CUSTOMER_H
