//
// Created by Fernandha Dzaky Saputra on 2019-06-12.
//
#include <cstdlib>
#include <iostream>
#include <time.h>
using namespace std;
#ifndef FINALPROJECT_TIME_H
#define FINALPROJECT_TIME_H

class Time{
public:

    // INTEGER HOUR , MINUTE AND SECOND
    int hh , mm , ss;

    void readtime(int h , int m , int s);
    string showtime();

    void addTime(Time , Time);

    int returnMinute(string time);
};


#endif //FINALPROJECT_TIME_H
