//
// Created by Fernandha Dzaky Saputra on 2019-06-13.
//
#include <cstdlib>
#include <iostream>
#include <string>
#include <iomanip>

#include "LinkedList.h"
#include "time.h"
#include "admin.h"

using namespace std;

// PRINTING ALL THE PARKING LOT
void LinkedList::showList(){
    Node * temp = head;
    if(temp == NULL){
        cout <<"there is no data" << endl;
    }
    else{
        while(temp!= NULL){
            cout << left << setw(15) << temp->lotNum;
            cout << left << setw(20) << temp->status;
            cout << left << setw(15) << temp->time;
            cout << left << setw(15) << temp->bookedBy;

            cout << endl << "-------------------------------------------------------------" << endl;
            temp = temp->next;
        }
    }

}

// ADDING PARKING LOT
void LinkedList::addParkingLot() {
    string lotNum;
    while(true) {

        cout << "Enter Lot Number : ";
        cin >> lotNum;
        // VALIDATION FOR THE LOT NUMBER IS ALREADY EXISTS
        bool val = lotNumCheck(lotNum);
        if(val){
            cout << "Lot Number has been used ! " << endl;


        }
        else
            break;
    }

    // SET ALL THE STATUS , TIME AND BOOKED BY AS EMPTY
    string status = "EMPTY";
    string time = "EMPTY";
    string bookedBy = "EMPTY";
    cout << "Parking Lot Added !" << endl;

    // TEMPORARY POINTER , POINTING TO NEW NODE
    Node * temp = new Node;
    temp->lotNum = lotNum;
    temp->status = status;
    temp->time = time;
    temp->bookedBy = bookedBy;

    // IF THERE IS NO DATA IN THE LINKED LIST , INSERT TO HEAD
    if(head == NULL){
        tail = temp;
        temp->next = NULL;
        temp->prev = NULL;
        head = temp;
    }
    // IF THERE IS DATA IN THE LINKED LIST , INSERT TAIL
    else{
        temp->next = NULL;
        temp->prev = tail;
        tail->next = temp;
        tail = temp;
    }
}

// BOOLEAN FUNCTION FOR VALIDATION OF LOTNUM FOR PARKING LOT
bool LinkedList::lotNumCheck(string lotNum) {
    Node * temp = head;
    while(temp!= NULL){
        if(lotNum == temp->lotNum){
            return true;
        }
        temp = temp->next;
    }
    return false;
}


// FUNCTION TO EMPTY THE LINKED LIST
void LinkedList::makeEmpty() {
    Node * temp;
    while(head != NULL){
        temp = head;
        head = temp->next;
        delete temp;
    }
}

// UPDATE THE LINKED LIST IF A CAR HAS BOOKED A PARKING LOT
int LinkedList::updatePark(string name , string time){
    int counter = 0;
    Node * temp = head;
    if(head == NULL) {
        return counter;

    }
    else {
        // IF THE HEAD OF THE LINKED LIST IS THE SEARCHED NODE , UPDATE THE NODE
        if(temp->bookedBy == "EMPTY"){
            temp->bookedBy = name;
            temp->time = time;
            temp->status = "ON-GOING";
            counter = 1;
            return counter;
        }
            // IF THE SEARCHED NODE IS NOT AT THE HEAD , TRAVERSE THROUGH THE LINKED LIST TO FIND THE SEARCHED NODE
        else{
            while(temp->bookedBy != "EMPTY"){
                temp = temp->next;
            }
            temp->bookedBy = name;
            temp->time = time;
            temp->status = "ON-GOING";
            counter = 1;
            return counter;
        }

    }

}

// FUNCTION FOR USER TO BOOK A PARKING LOT
void LinkedList::checkOnGoingBook(string name) {
    // TEMPORARY POINTER TO HEAD
    Node *temp = head;
    // IF THERE IS NO DATA IN THE LINKED LIST , PRINT TO PARKING SPOT
    if (head == NULL) {
        cout << endl << "There is no parking spot !" << endl;
    }
    // IF THERE IS / ARE DATA(s) IN THE LINKED LIST
    else {
        // IF THE HEAD OF THE LINKED LIST IS THE SEARCHED NAME , PRINT THE NODE
        if (temp->bookedBy == name) {
            admin.checkParkingLot();
            cout << left << setw(15) << temp->lotNum;
            cout << left << setw(20) << temp->status;
            cout << left << setw(15) << temp->time;
            cout << left << setw(15) << temp->bookedBy;
            cout << endl << "-----------------------------------------------------------" << endl;

        }
        // IF THE TAIL OF THE LINKED LIST IS THE SEARCHED NAME , PRINT THE NODE
        else if (tail->bookedBy == name) {
            admin.checkParkingLot();
            cout << left << setw(15) << tail->lotNum;
            cout << left << setw(20) << tail->status;
            cout << left << setw(15) << tail->time;
            cout << left << setw(15) << tail->bookedBy;
            cout << endl << "-----------------------------------------------------------" << endl;
        }
        //TRAVERSE THROUGH THE LINKED LIST TO FIND THE SEARCHED NAME , PRINT THE NODE IF FIND

        else {
            while (temp->bookedBy != name) {
                temp = temp->next;
            }
            admin.checkParkingLot();
            cout << left << setw(15) << temp->lotNum;
            cout << left << setw(20) << temp->status;
            cout << left << setw(15) << temp->time;
            cout << left << setw(15) << temp->bookedBy;
            cout << endl << "-----------------------------------------------------------" << endl;
        }
    }

}
// FUNCTION FOR USER TO PARK IN THEIR CAR AND UPDATE THE LINKED LIST STATUS
void LinkedList::park(string name) {
    Node * temp = head;
    if (head == NULL) {
        cout << endl << "There is no parking spot !" << endl;
    }
    else {
        // IF THE HEAD OF THE LINKED LIST IS THE SEARCHED NAME , PRINT THE NODE

        if (temp->bookedBy == name) {
            temp->status = "PARKED";
            temp->time = "-";

        // IF THE TAIL OF THE LINKED LIST IS THE SEARCHED NAME , PRINT THE NODE

        } else if (tail->bookedBy == name) {
            tail->status = "PARKED";
            tail->time = "-";
        }
        //TRAVERSE THROUGH THE LINKED LIST TO FIND THE SEARCHED NAME , PRINT THE NODE IF FIND

        else {
            while (temp->bookedBy != name) {
                temp = temp->next;
            }
            temp->status = "PARKED";
            temp->time = "-";
        }
    }
}

// FUNCTION FOR USER TO PARK OUT THEIR CAR AND UPDATE THE LINKED LIST STATUS

void LinkedList::parkOut(string name) {
    Node *temp = head;
    if (head == NULL) {
        cout << endl << "There is no parking spot !" << endl;
    }
    else {
        // IF THE HEAD OF THE LINKED LIST IS THE SEARCHED NAME
        if (temp->bookedBy == name) {
            // IF USER HASNT PARKED IN THEIR CAR , PRINT YOU HAVENT PARKED IN
            if(temp->status == "ON-GOING" || temp->status != "PARKED"){
                cout << "You havent parked in ! "<< endl;
            }
            // IF USER HAS PARKED IN THEIR CAR , UPDATE THE LIST TO EMPTY
            else{
                temp->status = "EMPTY";
                temp->time = "EMPTY";
                temp->bookedBy = "EMPTY";
                admin.totalCarParked -= 1;
                cout << "Car Went Out Successfully !" << endl;
            }

        // IF THE TAIL OF THE LINKED LIST IS THE SEARCHED NAME
        } else if (tail->bookedBy == name) {
            // IF USER HASNT PARKED IN THEIR CAR , PRINT YOU HAVENT PARKED IN

            if(temp->status == "ON-GOING" || temp->status != "PARKED"){
                cout << "You havent parked in ! "<< endl;
            }
            // IF USER HAS PARKED IN THEIR CAR , UPDATE THE LIST TO EMPTY

            else{
                temp->status = "EMPTY";
                temp->time = "EMPTY";
                temp->bookedBy = "EMPTY";
                admin.totalCarParked -= 1;
                cout << "Car Went Out Successfully !" << endl;
            }
        //TRAVERSE THROUGH THE LINKED LIST TO FIND THE SEARCHED NAME , PRINT THE NODE IF FIND
        } else {
            while (temp->bookedBy != name) {
                temp = temp->next;
            }
            // IF USER HASNT PARKED IN THEIR CAR , PRINT YOU HAVENT PARKED IN

            if(temp->status == "ON-GOING" || temp->status != "PARKED"){
                cout << "You havent parked in ! "<< endl;
            }
            // IF USER HAS PARKED IN THEIR CAR , UPDATE THE LIST TO EMPTY

            else{
                temp->status = "EMPTY";
                temp->time = "EMPTY";
                temp->bookedBy = "EMPTY";
                admin.totalCarParked -= 1;
                cout << "Car Went Out Successfully !" << endl;
            }
        }
    }
}

// BOOLEAN FUNCTION TO CHECK FOR THE SAME NAME
bool LinkedList::nameCheck(string name) {
        Node * temp = head;
        while(temp!= NULL){
            if(name == temp->bookedBy){
                return true;
            }
            temp = temp->next;
        }
        return false;
    }


// BOOLEAN FUNCTIONS WHETHER THE USER ALREADY BOOKED A PAKING LOT OR NOT
bool LinkedList::bookValidation(string username) {
    Node *temp = head;
    while(temp != NULL){
        if(temp->bookedBy == username){
            return true;
        } else
            temp = temp->next;
    }
    return false;

}


// FUNCTIONS TO REMOVE A NODE OR PARKING LOT
void LinkedList::removeParkingLot(string lotNum) {
        // TEMPORARY POINTER TO THE HEAD OF THE LINKED LIST
        Node* temp = head;
        // IF THE SEARCHED NODE IN THE HAD OF THE LINKED LIST , DELETE HEAD
        if(lotNum == head->lotNum){
            head = head->next;
            delete temp;
            length--;
        }
        // TRAVERSE THE LINKEDLIST
        else{
            // WHILE TEMPORARY POINTER IS NOT POINTING TO NULL AND THE NEXT NODE IS NOT THE SEARCHED NODE
            while(temp->next != NULL && (!(lotNum == temp->next->lotNum))){
                // TEMPORARY POINTER MOVE TO THE NEXT NODE
                temp = temp->next;
            }

            Node *target = temp->next;
            // IF THE TARGETTED NODE IS NOT AT THE TAIL , DELETE NODE
            if (target!=NULL){
                temp->next = target->next;
                delete target;
                length--;
            }
            // IF THE TARGETTED NODE IS AT THE TAIL , DELETE NODE
            else{
                temp->next = NULL;
                delete target;
                length --;
            }
        }
}

// BOOLEAN FUNCTION FOR QUEUE
bool LinkedList::thereIsOnGoingAndAllParked() {
    bool thereIsOnGoing = false;
    bool noEmpty = false;
    Node *temp = head;
    Node*curr = head;

    // IF THERE IS NO PARKING LOT , PRINT NO PARKING LOT
    if (head == NULL) {
        cout << endl << "There is no parking spot !" << endl;
    } else {
        // WHILE CURR POINTER IS NOT TO NULL , TRAVERSE TO LINKED LIST
        while(curr != NULL){
            // IF THERE IS EMPTY SPOT , RETURN FALSE
            if(curr->status == "EMPTY"){
                noEmpty = false;
            }
            else
                curr = curr->next;

        }
        // IF CURR POINTER IS POINTING TO NULL , THEN THERE IS NO EMPTY PARKING LOT
        if(curr == NULL){
            // RETURN TRUE
            noEmpty = true;
        }

        // IF THERE IS ON GOING PARKING LOT AT THE HEAD OF THE LIST
        if (temp->status == "ON-GOING") {
            thereIsOnGoing = true;

        }
         // IF THERE IS ON GOING PARKING LOT AT THE TAIL OF THE LIST

        else if (tail->status == "ON-GOING") {
            thereIsOnGoing = true;
        }

        // TRAVERSE THROUGH THE LINKED LIST TO SEARCH FOR THE ON GOING LIST
        else {
            while (temp->status != "ON-GOING") {
                temp = temp->next;
            }
            if(temp == NULL){
                thereIsOnGoing = false;
            }
        }
    }
    // IF THERE IS ON GOING AND THERE IS THERE IS NO EMPTY IN THE LIST , RETURN TRUE
    if(thereIsOnGoing && noEmpty){
        return true;
    }
    else{
        // ELSE RETURN FALSE
        return false;
    }
}

// FUNCTION TO RETURN THE TIME OF THE ON GOING BOOK
string LinkedList::getOnGoingTime() {
    Node * temp = head;
    // IF THE HEAD OF THE LINKED LIST IS ON GOING , RETURN THE TIME
    if(head->status=="ON-GOING"){
        // RETURN THE TIME OF THE ON GOING BOOK
        return temp->time;
    }
    else{
        // TRAVERSE THE LINKED LIST TO SEARCH FOR ON GOING
        while(temp->status != "ON-GOING"){
            // TEMPORARY POINTER TO THE NEXT NODE
            temp = temp->next;
        }
        // RETURN THE TIME OF THE ON GOING BOOKED
        return temp->time;
    }

}


// UPDATE THE LINKED LIST IF A USER PARKED THEIR CAR
void LinkedList::updateQueue(string name, string time) {
    Node*temp = head;
    // IF THE HEAD OF THE LINKED LIST IS THE NAME
    if(head->status=="ON-GOING"){
        temp->bookedBy = name;
        temp->time = time;
    }
    else{
        // TRAVERSE TO THE LINKED LIST

        while(temp->status != "ON-GOING"){
            temp = temp->next;
        }
        // CHANGE THE NAME AND THE TIME FROM EMPTY
        temp->bookedBy = name;
        temp->time = time;
    }
}




