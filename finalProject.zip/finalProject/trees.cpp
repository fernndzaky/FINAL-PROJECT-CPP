//
// Created by Fernandha Dzaky Saputra on 2019-06-24.
//
#include <iostream>
#include <string>
#include "trees.h"
using namespace std;

// CREATING NEW NODE AND ASSIGNING THE PROPERTY
Trees::Node * Trees::getNewNode(string name, int id) {
    Node * newNode = new Node();
    newNode->name = name;
    newNode->id = id;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// INSERTING THE NODE INTO TREE
Trees::Node * Trees::insert(Node* root ,string name,int id){
    // IF THERE IS NO DATA IN THE TREE , INSERT AT ROOT
    if(root == NULL){
        root = getNewNode(name, id);
        cout << "User Added" << endl;
        totalUser++;
        return root;
    }
    // IF SMALLER THAN THE ROOT , RECURSIVE FUNCTION
    else if(id <= root->id)
        root->left = insert(root->left , name , id);
    // IF HIGHER THAN THE ROOT , RECURSIVE FUNCTION
    else
        root->right = insert(root->right, name , id);
    return root;

}

// BOOLEAN FUNCTION TO SEARCH FOR A NODE IN THE TREEE
bool Trees::Search(Trees::Node *root, int id) {


    // IF THERE IS NO DATA IN THE TREE , RETURN FALSE
    if(root == NULL) return false;

    // IF THE ROOT IS THE DATA , RETURN TRUE
    else if(root->id == id){
        return true;
    }
    // RECURSIVE FUNCTION TO THE LEFT IF THE DATA IS SMALLER THEN THE ROOT
    else if(id <= root->id) return Search(root->left, id);
    // RECURSIVE FUNCTION TO THE RIGHT IF THE DATA IS SMALLER THEN THE ROOT
    else return Search(root->right , id);
}

// FUNCTION TO RETURN THE NAME OF THE USER FROM THE TREE
string Trees::getFullName(Trees::Node *root, int id) {
    // IF THERE IS NO DATA IN THE TREE ,  PRINT THERE IS NO USER !
    if(root == NULL) cout << "gak ada isi" << endl;
        // IF THE ROOT IS THE DATA , RETURN THE NAME

    else if(root->id == id)

        return root->name;

    // RECURSIVE FUNCTION TO THE LEFT IF THE DATA IS SMALLER THEN THE ROOT
    else if(id <= root->id) return getFullName(root->left, id);
    // RECURSIVE FUNCTION TO THE RIGHT IF THE DATA IS SMALLER THEN THE ROOT
    else if(id >= root->id) return getFullName(root->right , id);
}



// SNIPPET CODE FROM INTERNET TO PRINT THE TREE BY TRAVERSING FROM LEFT TO RIGHT
void Trees::showUser(Trees::Node *root) {
    if(root != NULL)
    {

        if(root->left)
            showUser(root->left);



        if(root->right)
            showUser(root->right);



        cout << "Name : " <<root->name<< "    " << "ID : " << root->id << endl;
    }
    else cout << "NO USERS !" << endl;

}
