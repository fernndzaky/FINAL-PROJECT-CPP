//
// Created by Fernandha Dzaky Saputra on 2019-06-12.
//
#include <iostream>
#include <string>
#include <iomanip>

#include "customer.h"
#include "time.h"
#include "LinkedList.h"



// PRINT THE MENU OF USER LOGIN
void Customer::printLogin() {

    cout << endl ;
    cout << "1. Check On Going Book" << endl
         << "2. Book Parking Lot" << endl
         << "3. Check Queue" << endl
         << "4. Logout" << endl << endl
         << "Enter Choice : ";
}



