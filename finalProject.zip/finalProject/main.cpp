#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>

#include "admin.h"
#include "customer.h"
#include "time.h"
#include "LinkedList.h"
#include "trees.h"

using namespace std;

// PRINTING THE ADMIN MENU
void printAdminMenu() {

    cout  << endl  << "WELCOME ADMIN" << endl << endl
          << "1. Check Parking Lot" << endl
          << "2. Add Parking Lot" << endl
          << "3. Remove Parking Lot" << endl
          << "4. Check Queue" << endl
          << "5. View User" << endl
          << "6. Back To Home" << endl << endl
          << "Enter Choice : ";

}
// PRINTING THE CUSTOMER MENU
void printCustomerMenu(){

    cout << endl << "WELCOME CUSTOMER"<< endl << endl
         << "1. Login" << endl
         << "2. Register" << endl
         << "3. Back To Home" << endl << endl
         << "Enter Choice : ";

}

// FUNCTION TO GET THE CURRENT TIME
string getCurrentTime(){
    Time t1 , t2 , t3;

    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    t1.readtime(tm.tm_hour,tm.tm_min,tm.tm_sec);
    t2.readtime(00 , 00 , 00);
    t3.addTime(t1,t2);
    string time = t3.showtime();
    return time;

}
// FUNCTION TO RETURN THE BOOKED TIME
string getBookingTime(){
    Time t1 , t2 , t3;

    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    t1.readtime(tm.tm_hour,tm.tm_min,tm.tm_sec);
    t2.readtime(00 , 01 , 00);
    t3.addTime(t1,t2);
    string time = t3.showtime();
    return time;
}

// BOOLEAN FUNCTION TO CHECK WHETHER CURRENT TIME IS GREATER THEN BOOKED TIME
bool nowTimeIsGreatedThenOnGoingTime(int t1 , int t2){
    // CURRENT TIME MINUS BOOKED TIME
    int result = t1-t2;
    // IF THE RESULT IS MINUS , THEN RETURN TRUE
    if(result < 0){
        return true;
    }
    else{
        // IF CURRENT TIME IS NOT GREATER THEN BOOKED TIME , PRINT THE DIFFERENCE
        cout << "Minutes Until The Next Parking Lot Open : " << result<< endl;
        return false;

    }

}



int main() {
    Admin admin;
    Customer cust;
    LinkedList linkedList;
    Trees trees;
    Time times;


    time_t tx = time(NULL);
    struct tm tmx = *localtime(&tx);





    while (true) {
        int choice;
        cout << endl << "Parking Booking " << endl << endl;
        cout         << "1. Admin" << endl
                     << "2. Customer" << endl
                     << "3. Exit" << endl << endl
                     << "Enter Choice : ";
        cin >> choice;
        // IF THE USER CHOOSE ADMIN
        if (choice == 1) {
            while (true){
                int adminChoice;
                // PRINTING THE ADMIN MENU
                printAdminMenu();
                cin >> adminChoice;
                if (adminChoice == 1) {
                    // IF THE ADMIN CHOOSE 1, PRINT THE PARKING LOT FROM LINKED LIST
                    admin.checkParkingLot();
                    linkedList.showList();
                } else if (adminChoice == 2) {
                        // IF THE ADMIN CHOOSE 2 , SHOW THE ADD FUNCTION AND ADD THE TOTAL PARKING LOT BY 1
                        linkedList.addParkingLot();
                        admin.totalParkingLot +=1 ;

                // IF THE ADMIN CHOOSE 3
                } else if (adminChoice == 3) {
                    if(admin.totalParkingLot == 0){
                        cout << "There is no parking space !" << endl;
                    }
                    else{
                        // SHOW THE LIST OF PARKING LOT AND USER CAN CHOOSE WHICH PARKING LOT TO DELETE BY INSERTING THE LOT NUMBER
                        admin.checkParkingLot();
                        linkedList.showList();
                        string lotNum;
                        cout << "Enter Lot Number that you want to delete : " ;
                        cin >>lotNum;
                        linkedList.removeParkingLot(lotNum);
                        cout << "Parking Lot Deleted !"<< endl;
                        admin.totalParkingLot--;
                    }

                // IF THE ADMIN CHOOSE 4 , CALL THE SHOWQUEUE FUNCTION FROM ADMIN CLASS
                } else if (adminChoice == 4) {
                    admin.showQueue();
                // IF THE ADMIN CHOOSE 5 , CALL THE SHOW USER FUNCTION FROM TREE CLASS
                } else if (adminChoice == 5) {
                    cout << "User Registered : " << endl;
                    trees.showUser(trees.root);
                // IF THE ADMIN CHOOSE 6 , EXIT FROM ADMIN MENU
                } else if (adminChoice == 6) {
                    break;
                } else
                    // IF THE ADMIN INPUT THE WRONG NUMBER
                    cout << "Wrong Input ! " << endl;

            }
        }

        // IF THE USER CHOOSE 2 , PRINT THE USER HOME MENU
        else if (choice == 2) {

            while(true){
                int customerChoice;
                // PRINT THE CUSTOMER HOME MENU
                printCustomerMenu();
                cin >> customerChoice;

                // IF CUSTOMER CHOOSE 1 , PRINT LOGIN FORM AND CUSTOMER CAN LOGIN
                if (customerChoice == 1) {

                    cout << left << setw(15) << "Enter ID";
                    cout << left << setw(2) << ":";
                    cin >>cust.id;
                    // SEARCH THE TREE IF THE USER IS EXISTS. IF EXISTS , SET THE ACTIVE USER AS THE NAME
                    if(trees.Search(trees.root , cust.id)){
                        cust.username = trees.getFullName(trees.root , cust.id);
                        cout << "Login Successful !" << endl;
                    }
                    // IF USER DOESNT EXIST , PRINT WRONG ID
                    else{
                        cout << "Wrong ID !" << endl;
                        break;
                    }
                    // IF USER SUCCESSFULY LOGIN , PRINT THE USER MENU
                    while(true){
                        int custChoice;
                        cust.printLogin();
                        cin >> custChoice;
                        // IF CUSTOMER CHOOSE 1
                        if(custChoice == 1){
                            // IF THE USER HAS ALREAY BOOK A PARKING LOT , PRINT THEIR PARKING LOT ALONG WITH THE STATUS AND THE TIME THEY BOOKED
                            if(linkedList.bookValidation(cust.username)){
                                int parkChoice;
                                linkedList.checkOnGoingBook(cust.username);
                                cout << endl
                                     << "1. Park In" << endl
                                     << "2. Park Out" << endl
                                     << "3. Back To User Home" << endl
                                     << "Enter Choice : ";
                                cin >> parkChoice;
                                // IF CUSTOMER CHOOSE 1 , UPDATE THEIR STATUS INTO PARKED
                                if(parkChoice == 1){
                                    linkedList.park(cust.username);
                                    cout << "Car Parked Successfully !" << endl;
                                }
                                // IF CUSTOMER CHOOSE 2 , UPDATE THEIR STATUS INTO EMPTY
                                else if(parkChoice == 2){
                                    linkedList.parkOut(cust.username);


                                }
                                // IF CUSTOMER CHOOSE 3 , BACK TO USER MENU
                                else if(parkChoice == 3){
                                    cout <<endl;
                                }

                            }
                            // IF THE USER HASNT BOOKED YET , PRINT
                            else
                                cout << "You havent book yet !" << endl;
                        }

                        // IF CUSTOMER CHOOSE 2
                        else if( custChoice == 2){
                            // GET THE CURRENT TIME
                            string time = getBookingTime();
                            string price = "15000";
                            // IF ALL PARKING LOT IS FULLY BOOKED AND THERE IS A PARKING LOT AND THE USER HASNT BOOKED A PARKING LOT , THE USER WILL BE PUT IN A QUEUE
                            if(admin.totalCarParked == admin.totalParkingLot && admin.totalParkingLot > 0 && !linkedList.nameCheck(cust.username)){
                                while(true){
                                    cout << "All Parking Lot is fully booked !" << endl;
                                    // CHECK IF THE USER IS ALREAY IN THE QUEUE
                                    if(admin.findUserInQueue(cust.username)){
                                        cout << "You are already in a Queue ,Please check your Queue !" << endl;
                                        break;
                                    }
                                    // IF THE USER IS NOT IN THE QUEUE
                                    else{
                                        cout << "Do you want to be in Queue ? (Y/N) : ";
                                        char ans;
                                        cin >> ans;
                                        if(ans == 'y' || ans == 'Y') {
                                            // PUSH THE NAME OF THE USER TO THE QUEUE LIST
                                            admin.userQueue.push(cust.username);
                                            cout << "You are in the Queue !" << endl;
                                            break;
                                        }
                                        else if(ans == 'n' || ans == 'N'){
                                            cout << "Ok You are not going to be in the Queue !"<<endl;
                                            break;

                                        }
                                        else{
                                            cout << "Wrong Input !" << endl;

                                        }
                                    }

                                }

                            }
                            // IF THE USER HAS ALREADY BOOK A PARKING LOT
                            else if(linkedList.nameCheck(cust.username)){
                                cout << "You already have on-going book  !" << endl;

                            }
                            // THERE IS NO PARKING SPACE
                            else if(linkedList.updatePark(cust.username ,time ) == 0){
                                cout << "There is no parking space !" << endl;

                            }
                            // IF THERE IS PARKING SPACE , USER CAN PARK THEIR CAR
                            else{
                                cout << endl;
                                cout << left << setw(15) << "Estimated Time";
                                cout << left << setw(2) << ": ";
                                cout << getBookingTime();

                                // price = 500 * timeArrive;
                                cout << endl;
                                cout << left << setw(15) << "Please Pay" ;
                                cout << left << setw(2) << ": ";
                                cout << "Rp." << price;
                                cout << endl << "Parking Lot Booked Succesfully !" << endl << endl;
                                admin.totalCarParked +=1;
                            }




                        }
                        // IF THE USER CHOOSE 3 , THEY CAN CHECK THEIR QUEUE
                        else if( custChoice == 3){

                            string time = getCurrentTime();
                            if(admin.findUserInQueue(cust.username)){
                                //IF THE USER IS IN THE QUEUE && AND ALL PARKING LOT IS TAKEN
                                if(linkedList.thereIsOnGoingAndAllParked()){
                                    // GET CURRENT TIME AND THE ON GOING TIME IN THE PARKING LOT , AND MINUS THE TIME
                                    string t11 = linkedList.getOnGoingTime();
                                    int a = times.returnMinute(t11);
                                    int b = times.returnMinute(time);
                                    // IF THE CURRENT TIME IS GREATED THAN THE BOOKED TIME, THE USER WILL REPLACE IT
                                    if(nowTimeIsGreatedThenOnGoingTime(a,b)){
                                        cout << left << setw(15) << "Current Time" ;
                                        cout << left << setw(2) << ": ";
                                        cout << time << endl;
                                        cout << left << setw(15) << "Please Pay" ;
                                        cout << left << setw(2) << ": ";
                                        cout << "Rp. 15.000" << endl;
                                        // UPDATE THE PARK FROM THE CURRENT BOOKED
                                        linkedList.updateQueue(admin.userQueue.front() ,time);
                                        admin.userQueue.pop();
                                        cout << "You got a Parking Lot !"<< endl;
                                    }
                                }
                            }
                            else{
                                cout << "You are not in the queue !" << endl;
                            }

                        }
                        // IF USER CHOOSE 4 , SET THE CURRENT ACTIVE USERNAME TO EMPTY STRING
                        else if( custChoice == 4){
                            cust.username = "";
                           break;
                        }
                        else cout << "Wrong Input !" << endl;

                    }
                // IF USER CHOOSE 2 , THEY CAN REGISTER
                } else if (customerChoice == 2) {
                    string username;
                    cout << left << setw(18) << "Enter Full Name";
                    cout << left << setw(2) << ":";
                    cin.ignore();
                    getline(cin, username);

                    // GIVING A RANDOM NUMBER FROM 0 TO 1000 FOR THEIR ID
                    int id = rand() % 100 + (1);
                    // INSERT TO TREES
                    trees.root = trees.insert(trees.root , username ,id );
                    cout << endl << "ALWAYS REMEMBER YOUR ID !" << endl;
                    cout << left << setw(15) << "ID";
                    cout << left << setw(2) << ": ";
                    cout << id << endl;
                    cout << left << setw(15) << "Full Name";
                    cout << left << setw(2) << ": ";
                    cout << username << endl;



                } else if (customerChoice == 3) {
                    break;


                }
                else
                    cout << "Wrong Input! " << endl;

                }
        // IF USER CHOOSE 3 , EXIT PROGRAM
        } else if (choice == 3) {
            cout << "Exiting ! .." << endl;
            return 0;
        }
        // IF USER CHOOSE THE WRONG NUMBER , PRINT WRONG INPUT !
        else
            cout << "Wrong Input !" << endl;
    }

}

