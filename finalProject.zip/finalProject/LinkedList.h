//
// Created by Fernandha Dzaky Saputra on 2019-06-13.
//
#include <iostream>
#include <string>
#include "admin.h"
using namespace std;
#ifndef FINALPROJECT_LINKEDLIST_H
#define FINALPROJECT_LINKEDLIST_H

class LinkedList{
    Admin admin;

    // STRUCT FOR EACH NODE
    struct Node{
        string lotNum;
        string status;
        string time;
        string bookedBy;
        Node*next;
        Node*prev;
    };

public:
    int length;
    Node * head;
    Node * tail;
    // CONSTRUCTOR FOR LINKEDLIST
    LinkedList(){
        length=0;
        head = NULL;
        tail = NULL;

    }
    // DECONSTRUCTOR FOR LINKEDLIST
    ~LinkedList(){
        makeEmpty();

    }


    void showList();
    void addParkingLot();
    void removeParkingLot(string lotNum);
    void makeEmpty();
    bool lotNumCheck(string lotNum);
    int updatePark(string name , string time);
    void checkOnGoingBook(string name);
    bool nameCheck(string name);
    bool bookValidation(string username);
    void park(string name);
    void parkOut(string name);
    bool thereIsOnGoingAndAllParked();
    string getOnGoingTime();
    void updateQueue(string name , string time);

};

#endif //FINALPROJECT_LINKEDLIST_H
