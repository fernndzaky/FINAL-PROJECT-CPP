//
// Created by Fernandha Dzaky Saputra on 2019-06-12.
//

#include <iostream>
#include <string>
#include <queue>


using namespace std;

#ifndef FINALPROJECT_ADMIN_H
#define FINALPROJECT_ADMIN_H

class Admin{

public:

    queue <string> userQueue;
    queue <string> tempQueue;
    queue <string> currQueue;

    int totalParkingLot;
    int totalCarParked;

    void showQueue();
    bool isQueueEmpty();
    void checkParkingLot();
    void addParkingLot();
    bool findUserInQueue(string username);

};

#endif //FINALPROJECT_ADMIN_H
